<!DOCTYPE html>
<head>
 	<title>pelajari</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b></font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
		<ul>
	<li class="dropdown"><a href="#">absen</a>
				<ul class="isi-dropdown">
		<nav>		
		 <li align='left'><a href="../file lap/absen Jan 2021.htm"target="blank"><font face="Time new roman"size="4"><font color='blue'>absen jan 2021</font></a></li>
		</ul>
<li class="dropdown"><a href="#">bpb study</a>
	     <ul class="isi-dropdown">
		<li><a href="pendaftaran po.pdf" target="blank"><font color='blue'>daftar po<font/></a></li>
		<li><a href="retur toko tutup.pdf" target="blank"><font color='blue'>proses RTT<font/></a></li>
		<li><a href="Receiving/Kesegaran Barang Dagangan.pptx" target="blank"><font color='blue'>kesegaran produk<font/></a></li>
		</ul>
<li class="dropdown"><a href="#">Retur</a>
	     <ul class="isi-dropdown">
		<li align='left'><a href="nrb"><font face="Time new roman"size="4"><font color='blue'>Intranst nrb</font></a></li>
		<li><a href="Receiving/Program Retur TTD SMRT RETURTOKOPC NRB WEB update alasan lokasi 03.pptx" target="blank"><font color='blue'>penjawaban retur nrb toko<font/></a></li>
		</ul>
<li class="dropdown"><a href="#">return</a>
	    <ul class="isi-dropdown">
		<li><a href="draft retur.pdf" target="blank"><font color='blue'>draft retur<font/></a></li>
		<li><a href="Penanganan Retur Suplier di luar N R F.pdf" target="blank"><font color='blue'>Memo sepihak<font/></a></li>
		<li><a href="SOP Pengambilan Retur Khusus.pdf" target="blank"><font color='blue'>sup khsusus return<font/></a></li>
		</ul>		
	</nav>	
  </header>
</bodY>


