	<!DOCTYPE html>
<head>
 	<title>pelajari</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b>Information</font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
		<ul>
	<li class="dropdown"><a href="#">Absen</a>
				<ul class="isi-dropdown">
		<nav>		
		 <li align='left'><a href="../file lap/absen Jan 2021.htm"target="blank"><font face="Time new roman"size="4"><font color='blue'>absen jan 2021</font></a></li>
		</ul>
    <li class="dropdown"><a href="#">stock toko</a>
		<ul class="isi-dropdown">
		<nav>
		<li><a href="http://192.168.36.117/phpscript/B00/ex_laptagndc.php"target="blank"><font face="time new roman"size="4"><font color='blue'>Tag N&R </a></li>
		<li><a href="http://192.168.36.117/phpscript/100/lapstkitem.php"target="blank"><font face="time new roman"size="4"><font color='blue'>Query toko</a></li>
		<li><a href="http://192.168.36.117/phpscript/300/data_stock_plu.php"target="blank"><font face="time new roman"size="4"><font color='blue'> stock toko</a></li>
	   </ul> 
    <li class="dropdown"><a href="#">Retur</a>
		<ul class="isi-dropdown">
		<nav>
		<li><a href="http://192.168.36.117/phpscript/100/retur_plu.php"target="balnk"><font face="time new roman"size="4"><font color='blue'> Retur prdcd</a></li>
	    <li><a href="http://192.168.36.117/phpscript/100/lapnrbprfrma.php"target="balnk"><font face="time new roman"size="4"><font color='blue'> retur profrma</a></li>
	   </ul>    	   
	</nav>	
  </header>
</bodY>