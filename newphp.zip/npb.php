<!DOCTYPE html>
<head>
 	<title>pelajari</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b></font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
		<ul>
	<li class="dropdown"><a href="#">absen</a>
				<ul class="isi-dropdown">
		<nav>		
		 <li align='left'><a href="../file lap/absen Jan 2021.htm"target="blank"><font face="Time new roman"size="4"><font color='blue'>absen jan 2021</font></a></li>
		</ul>
    <li class="dropdown"><a href="#">Npb Study</a>
	     <ul class="isi-dropdown">
		 <li><a href="../file lap/pecah pb toko baru.pdf" target="blank"><font color='blue'>pecah pb<font/></a></li>
		 <li><a href="../file lap/pbro.pdf" target="blank"><font color='blue'>pbro<font/></a></li>
		 <li><a href="../file lap/program jadwal pb toko.pdf" target="blank"><font color='blue'>set jadwal pb<font/></a></li>
		 <li><a href="../file lap/put2light.pdf" target="blank"><font color='blue'>picking kartel<font/></a></li>
		 <li><a href="../file lap/PBRO alasan time skip.pdf" target="blank"><font color='blue'>pbro baru<font/></a></li>
		 <li><a href="../Program Buah-mekanisme baru.pdf" target="blank"><font color='blue'>Pog buah baru<font/></a></li>
		 <li><a href="../Mr Bread - jadwal kirim dan file NBR ke IT SD 05.pdf" target="blank"><font color='blue'>Jadwal Roti<font/></a></li>
			  </ul>
<li class="dropdown"><a href="#">Prog</a>
	     <ul class="isi-dropdown">
		<li align='left'><a href="masdc.zip"><font face="Time new roman"size="4"><font color='blue'>masdc</font></a></li>
		<li align='left'><a href="../../../prog/BACKUPPBBUAH_v1126B.zip"><font face="Time new roman"size="4"><font color='blue'>backupbuah</font></a></li>
		<li align='left'><a href="../../../prog/DCTABLOKPLANPSP_V1007.zip"><font face="Time new roman"size="4"><font color='blue'>dctablokplano</font></a></li>
		<li align='left'><a href="../../../prog/JadwalRoti Versi 1000.zip"><font face="Time new roman"size="4"><font color='blue'>dcjadwalroti</font></a></li>
		<li align='left'><a href="../../../prog/DCKIRIMBUAH_1001.zip"><font face="Time new roman"size="4"><font color='blue'>jdwalkrmbuah</font></a></li>
		</ul>
<li class="dropdown"><a href="#">rutting maps</a>
	    <ul class="isi-dropdown">
		<li align='left'><a href="../prog update/AUTOCLUSTER - Kelompok Kirim.pdf"><font face="Time new roman"size="4"><font color='blue'>rutting g maps</font></a></li>
		</ul>
	</nav>	
  </header>
</bodY>


