<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Option</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="#">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">option</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">option</a>
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<center><h3>SISTEM INFORMASI</h3>
									<h4>RECEIVING TGR 1</h4></center>
								</div>
							</div>
						</div>
					</div>
				</div>