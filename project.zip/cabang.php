<!DOCTYPE html>
<head>
 	<title>pelajari</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b></font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
	<ul>
	<li class="dropdown"><a href="#">Stock Toko </a>
	     <ul class="isi-dropdown">
		<li><a href="http://192.168.36.117/phpscript/200/stock_out.php" target="blank"><font color='blue'>Stock Out toko<font/></a></li>
		<li><a href="http://192.168.36.117/phpscript/100/lapstkitem.php" target="blank"><font color='blue'>Query stock toko/item<font/></a></li>
		<li><a href="http://192.168.36.117/phpscript/100/lapcntperprdcd.php" target="blank"><font color='blue'>Stock toko prdcd<font/></a></li>
		<li><a href="http://192.168.36.117/phpscript/100/stockout/index.php" target="blank"><font color='blue'>Stock out toko prdcd<font/></a></li>
		</ul>
<li class="dropdown"><a href="#">Spd toko</a>
	     <ul class="isi-dropdown">
		<li align='left'><a href="http://192.168.36.117/phpscript/300/ex_lapslsnetmrgplb.php" target="blank"><font face="Time new roman"size="4"><font color='blue'>Spd toko by date</font></a></li>
		<li><a href="http://192.168.36.117/phpscript/200/lapsls1.php" target="blank"><font color='blue'>Trend SPD, STD, APC per Toko<font/></a></li>
		</ul>
<li class="dropdown"><a href="#">Return</a>
	    <ul class="isi-dropdown">
		<li><a href="http://192.168.36.117/phpscript/100/lapnrbprfrma.php" target="blank"><font color='blue'>data retur profrma toko<font/></a></li>
		<li><a href="http://192.168.36.117/phpscript/100/retur_plu.php" target="blank"><font color='blue'>Returan toko plu<font/></a></li>
		</ul>		
	</nav>	
  </header>
</bodY>