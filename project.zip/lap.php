<!DOCTYPE html>
<head>
 	<title>pelajari</title>
 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b></font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
		<ul>
	<li class="dropdown"><a href="#">Absen</a>
				<ul class="isi-dropdown">
		<nav>		
		 <li align='left'><a href="../file lap/absen Nov 21.htm"target="blank"><font face="Time new roman"size="4"><font color='blue'>absen Nov 21</font></a></li>
		</ul>
    <li class="dropdown"><a href="#">File laporan</a>
		<ul class="isi-dropdown">
		<li align='left'><a href="../rcv"target="blank"><font face="Time new roman"size="4"><font color='blue'>lap rcv</font></a></li>
		<li align='left'><a href="../beban dc"target="blank"><font face="Time new roman"size="4"><font color='blue'>nrb beban dc</font></a></li>
		<li align='left'><a href="../memo"target="balnk"><font face="Time new roman"size="4"><font color='blue'>Memo supp	</font></a></li>
		<li align='left'><a href="../nrb sepihak"target="blank"><font face="Time new roman"size="4"><font color='blue'>Update NRB sepihak</font></a></li>
		<li align='left'><a href="../Stock"target="blank"><font face="Time new roman"size="4"><font color='blue'>Stock lpp h -1</font></a></li>
		<li align='left'><a href="../Rekap supp return khsusus"target="blank"><font face="Time new roman"size="4"><font color='blue'>Supp khusus return</font></a></li>
	   </ul>
	</nav>	
  </header>
</bodY>


