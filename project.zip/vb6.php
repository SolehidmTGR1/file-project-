 <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<head>
 <p align="left">
<font face="Times New Roman"size="4"><font color='red+blue'><b></font><br>
</head>
<body>
<header class="header">
	<div class="menu-solehngoding">
	<div class="menu">
	<ul class="nav">
		<ul>
	<li class="dropdown"><a href="#">absen</a>
				<ul class="isi-dropdown">
		<nav>		
		 <li align='left'><a href="../file lap/absen nov 21.htm"target="blank"><font face="Time new roman"size="4"><font color='blue'>absen Nov 21</font></a></li>
		</ul>
    <li class="dropdown"><a href="#">vb06 study</a>
		<ul class="isi-dropdown">
		<li align='left'><a href="../../../VB/vb1.pdf"target="blank><font face="Time new roman"size="4"><font color='blue'>task VB1</font></a></li>
		<li align='left'><a href="../../../VB/vb2.pdf"target="blank><font face="Time new roman"size="4"><font color='blue'>task VB2</font></a></li>
		<li align='left'><a href="../../../VB/vb2.pdf"target="blank><font face="Time new roman"size="4"><font color='blue'>task VB3</font></a></li>
			   </ul>
	  </nav>	
  </header>
</bodY>
